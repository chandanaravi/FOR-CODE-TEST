﻿namespace forcodetestWebApp.Models
{
    public class Offer
    {
        public Offer() { }  
        public Offer(string? _offerName , IList<Product> _products) 
        { 
            OfferName = _offerName;
            Products = _products;
        }
        public string? OfferName { get; set; }
        public IList<Product> Products { get; set; }

    }
}
