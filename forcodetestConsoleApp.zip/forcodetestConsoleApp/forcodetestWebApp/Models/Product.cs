﻿namespace forcodetestWebApp.Models
{
    public class Product
    {
        public Product() { }
        public Product(string _productName,decimal _price,string _dessc) 
        { 
            ProductName = _productName;
            Price = _price;
            Description = _dessc;
        }

        public string ProductName { get; set; } = string.Empty;
        public decimal Price { get; set; }
        public string? Description { get; set; }
    }
}
