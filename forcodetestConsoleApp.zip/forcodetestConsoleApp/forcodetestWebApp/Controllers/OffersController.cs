﻿using forcodetestWebApp.AppServices;
using forcodetestWebApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace forcodetestWebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OffersController : ControllerBase
    {
        private readonly IOfferService offerService;

        public OffersController( IOfferService _offerService)
        {
            offerService = _offerService;   
        }

        [HttpGet]
        [Route("GetTodaysOffers")]
        public async Task< IActionResult> GetTodaysOffers()
        {
            return Ok(offerService.GetTodaysOffers());  
        }

        [HttpGet]
        [Route("GetAllProducts")]
        public async Task<IActionResult> GetAllProducts()
        {
            var data=offerService.GetAllProducts();
            var result = data.OrderBy(x => x).Take(3).ToList();
            return Ok(result);
        }

        [HttpGet]
        [Route("Get2ndLowestProduct")]
        public async Task<IActionResult> Get2ndLowestProduct()
        {
            var data = offerService.GetAllProducts();
            var result = data.OrderBy(x => x).Take(2).Skip(1).FirstOrDefault();
            return Ok(result);
        }

        [HttpPost]
        [Route("AddProduct")]
        public async Task<IActionResult> AddNewProduct(Product product)
        {
            offerService.AddProduct(product);
            return Ok("Product Added");
        }
    }
}
