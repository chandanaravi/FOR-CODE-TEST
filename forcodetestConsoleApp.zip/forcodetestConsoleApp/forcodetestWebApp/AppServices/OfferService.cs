﻿using forcodetestWebApp.Models;
using Microsoft.AspNetCore.Diagnostics;

namespace forcodetestWebApp.AppServices
{
    public class OfferService : IOfferService
    {
        private IList<Product> Inventory;

        public OfferService() { 

            InitData();
        }

        private void InitData()
        {
            Inventory = new List<Product>();
            Inventory.Add(new Product { ProductName = "P1", Price = 1000, Description = "P1 DESC" });
            Inventory.Add(new Product { ProductName = "P2", Price = 200, Description = "P2 DESC" });
            Inventory.Add(new Product { ProductName = "P3", Price = 400, Description = "P3 DESC" });
            Inventory.Add(new Product { ProductName = "P4", Price = 700, Description = "P4 DESC" });
            Inventory.Add(new Product { ProductName = "P5", Price = 600, Description = "P5 DESC" });
            Inventory.Add(new Product { ProductName = "P6", Price = 800, Description = "P6 DESC" });
        }

        public IList<Product> GetAllProducts()
        {
            if(Inventory == null)
                InitData();
            return Inventory;
        }

        public IList<Offer> GetTodaysOffers()
        {
            if (Inventory != null)
                InitData();

            var r=new Random();
            
            IList<Offer> todayOffers=new List<Offer>();
            int count = 0;
            foreach(var item in todayOffers)
            {
                count++;    
                Offer offer = new Offer();
                offer.OfferName = $"ComboPackage{count}";
                offer.Products = new List<Product>();
                for(int i = 0; i < 3; i++)
                {
                    offer.Products.Add(Inventory[r.Next(0, 5)]);
                }

                todayOffers.Add(offer);
                
                
            }
            return todayOffers;

        }

        public void AddProduct(Product product)
        {
            Inventory.Add(product);
        }
    }

    public interface IOfferService
    {
        IList<Product> GetAllProducts();
        IList<Offer> GetTodaysOffers();
    }
}
