﻿//// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");

using System.Globalization;
using System.Text;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine(getRevString("RAVI"));
        for(int i=1; i <= 100; i++)
        {
            if(i%3==0)
            {
                Console.WriteLine("fizz");
            }
            else if(i%5==0)
            {
                Console.WriteLine("buzz");
            }
            if(i%3==0 && i%5==0)
            {
                Console.WriteLine("fizzbuzz");
            }
        }
    }

    public static string getRevString(string st)
    {
        int len=st.Length;
        StringBuilder sb = new StringBuilder();
        while (len>0)
        {
            sb.Append(st.ToCharArray()[len-1]);
            len--;
        }
        return sb.ToString();
         
    }
}